// Gole Khaja Ghar Service Worker
self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener('push', (event) => {
  if (!event.data) return;

  try {
    let data;
    try {
      data = event.data.json();
    } catch {
      data = { title: 'Gole Khaja Ghar', body: event.data.text() };
    }

    const title = data.title || '🍲 Gole Khaja Ghar Update';
    const body =
      data.body ||
      data.message ||
      'You have an update regarding your order at Gole Khaja Ghar.';
    const targetUrl =
      data.url ||
      (data.orderNumber ? `/orders/${data.orderNumber}` : data.linkUrl || '/');

    const options = {
      body,
      icon: data.icon || '/favicon-circle.png',
      badge: '/favicon-circle.png',
      image: data.image || undefined,
      data: {
        url: targetUrl,
        orderId: data.orderId,
        orderNumber: data.orderNumber,
        timestamp: Date.now(),
      },
      vibrate: [300, 100, 300, 100, 400],
      tag: data.tag || `gkg-${data.orderNumber || Date.now()}`,
      renotify: true,
      requireInteraction: true,
      silent: false,
      actions: [
        {
          action: 'open',
          title: '👉 View Order',
        },
        {
          action: 'dismiss',
          title: 'Dismiss',
        },
      ],
    };

    event.waitUntil(self.registration.showNotification(title, options));
  } catch (err) {
    console.error('[SW] Push error:', err);
    event.waitUntil(
      self.registration.showNotification('🍲 Gole Khaja Ghar', {
        body: event.data ? event.data.text() : 'New order update received.',
        icon: '/favicon-circle.png',
        badge: '/favicon-circle.png',
        vibrate: [300, 100, 300],
      })
    );
  }
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  if (event.action === 'dismiss') {
    return;
  }

  const targetUrl = event.notification.data?.url || '/';

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if (client.url && 'focus' in client) {
          if ('navigate' in client) {
            client.navigate(targetUrl);
          }
          return client.focus();
        }
      }
      if (clients.openWindow) {
        return clients.openWindow(targetUrl);
      }
    })
  );
});
